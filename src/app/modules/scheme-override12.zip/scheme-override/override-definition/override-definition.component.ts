import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { CommonService } from '../../../core/env/common-services/common.service';
import { EnvFunction } from 'src/app/core/env/function/env-function';

import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-override-definition',
  templateUrl: './override-definition.component.html',
  styleUrls: ['./override-definition.component.scss'],
})
export class OverrideDefinitionComponent implements OnInit {
  @Output('parentFun') parentFun: EventEmitter<any> = new EventEmitter();
  public formOverrideDetails: FormGroup;
  buttonLabel: String;
  valueList: any = [];
  schemes: any = [];
  zones: any = [];
  regions: any = [];
  branches: any = [];
  submitted: boolean = false;
  overrideFlag = 0;
  checkBoxVal: any = [];
  constructor(
    private fb: FormBuilder,
    private commonServices: CommonService,
    private envFn: EnvFunction,
    private route: ActivatedRoute,
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.getSchemeDetails();
    this.getZones();
    this.getRegions();
    this.getBranches();
    this.urlChecking()
  }

  private createForm(): void {
    this.formOverrideDetails = this.fb.group({
      interestOverride: new FormControl(false),
      chargeOverride: new FormControl(false),
      limitOverride: new FormControl(false),
      schemeName: new FormControl('', [Validators.required]),
      hideCheckbox: new FormControl('', [Validators.required]),

      schemeOverrideApplicable: new FormControl('', [Validators.required]),
      zone: new FormControl('', [Validators.required]),
      region: new FormControl('', [Validators.required]),
      branch: new FormControl('', [Validators.required]),
    });
  }

  public urlChecking(){
    if (this.route.snapshot.params['editTran']) {
      this.formOverrideDetails.get('schemeName')?.setValue(this.commonServices.override.schemeId)
      this.formOverrideDetails.get('schemeOverrideApplicable')?.setValue(this.commonServices.override.groupTypeId)
      // this.formOverrideDetails.get('schemeOverrideApplicable')?.setValue(this.commonServices.override.groupTypeId)
      // alert(this.commonServices.override.groupTypeId)
      // alert('def')
        if(this.commonServices.override.schemeInterestDefinition.length>0) this.formOverrideDetails.get('interestOverride')?.setValue(true)
        if(this.commonServices.override.schemeCharges.length>0) this.formOverrideDetails.get('chargeOverride')?.setValue(true)
     
        if (this.commonServices.override.groupTypeId==4) {
          this.buttonLabel = 'Add Branches';
          this.formOverrideDetails.get('region')?.clearValidators();
          this.formOverrideDetails.get('region')?.updateValueAndValidity();
          this.formOverrideDetails.get('zone')?.clearValidators();
          this.formOverrideDetails.get('zone')?.updateValueAndValidity();
          this.formOverrideDetails
            .get('branch')
            ?.setValidators([Validators.required]);
          this.formOverrideDetails.get('branch')?.updateValueAndValidity();
        }
         if (this.commonServices.override.groupTypeId==3) { 
          this.buttonLabel = 'Add Regions';
          this.formOverrideDetails.get('branch')?.clearValidators();
          this.formOverrideDetails.get('branch')?.updateValueAndValidity();
          this.formOverrideDetails.get('zone')?.clearValidators();
          this.formOverrideDetails.get('zone')?.updateValueAndValidity();
          this.formOverrideDetails
            .get('region')
            ?.setValidators([Validators.required]);
          this.formOverrideDetails.get('branch')?.updateValueAndValidity();
        }
        if (this.commonServices.override.groupTypeId==2) {
          this.buttonLabel = 'Add Zones';
          this.formOverrideDetails.get('branch')?.clearValidators();
          this.formOverrideDetails.get('branch')?.updateValueAndValidity();
          this.formOverrideDetails.get('region')?.clearValidators();
          this.formOverrideDetails.get('region')?.updateValueAndValidity();
          this.formOverrideDetails
            .get('zone')
            ?.setValidators([Validators.required]);
          this.formOverrideDetails.get('zone')?.updateValueAndValidity();
  
   
        }
      
    }else{
// alert(2)
    }
  }

  changeValue(event: any) {
    this.valueList = [];
    switch (event.target.value) {
      case '4': {
        this.buttonLabel = 'Add Branches';
        this.formOverrideDetails.get('region')?.clearValidators();
        this.formOverrideDetails.get('region')?.updateValueAndValidity();
        this.formOverrideDetails.get('zone')?.clearValidators();
        this.formOverrideDetails.get('zone')?.updateValueAndValidity();
        this.formOverrideDetails
          .get('branch')
          ?.setValidators([Validators.required]);
        this.formOverrideDetails.get('branch')?.updateValueAndValidity();
        break;
      }
      case '2': {
        this.buttonLabel = 'Add Regions';
        this.formOverrideDetails.get('branch')?.clearValidators();
        this.formOverrideDetails.get('branch')?.updateValueAndValidity();
        this.formOverrideDetails.get('zone')?.clearValidators();
        this.formOverrideDetails.get('zone')?.updateValueAndValidity();
        this.formOverrideDetails
          .get('region')
          ?.setValidators([Validators.required]);
        this.formOverrideDetails.get('branch')?.updateValueAndValidity();
        break;
      }
      case '3': {
        this.buttonLabel = 'Add Zones';
        this.formOverrideDetails.get('branch')?.clearValidators();
        this.formOverrideDetails.get('branch')?.updateValueAndValidity();
        this.formOverrideDetails.get('region')?.clearValidators();
        this.formOverrideDetails.get('region')?.updateValueAndValidity();
        this.formOverrideDetails
          .get('zone')
          ?.setValidators([Validators.required]);
        this.formOverrideDetails.get('zone')?.updateValueAndValidity();

        break;
      }
    }
  }

  addValues() {
    this.submitted = true;
    if (
      this.formOverrideDetails.value.interestOverride == true ||
      this.formOverrideDetails.value.chargeOverride == true ||
      this.formOverrideDetails.value.limitOverride == true
    ) {
      this.overrideFlag = 0;
      this.formOverrideDetails.get('hideCheckbox')?.clearValidators();
      this.formOverrideDetails.get('hideCheckbox')?.updateValueAndValidity();
    } else {
      this.overrideFlag = 1;
      this.formOverrideDetails
        .get('hideCheckbox')
        ?.setValidators([Validators.required]);
      this.formOverrideDetails.get('hideCheckbox')?.updateValueAndValidity();
    alert("select atleast  one override")
    }

    if (!this.formOverrideDetails.valid) {
      return;
    } else {
      if (this.formOverrideDetails.value.schemeOverrideApplicable == 4) {
        if (!this.valueList.includes(this.formOverrideDetails.value.branch)) {
          this.valueList.push(this.formOverrideDetails.value.branch);
        }
      }

      if (this.formOverrideDetails.value.schemeOverrideApplicable == 2) {
        if (!this.valueList.includes(this.formOverrideDetails.value.region)) {
          this.valueList.push(this.formOverrideDetails.value.region);
        }
      }
      if (this.formOverrideDetails.value.schemeOverrideApplicable == 3) {
        if (!this.valueList.includes(this.formOverrideDetails.value.zone)) {
          this.valueList.push(this.formOverrideDetails.value.zone);
        }
      }
    }
  }

  getSchemeDetails() {
    this.commonServices.getSchemeList(false).subscribe((res) => {
      this.schemes = res.result;
      console.log(this.schemes);
    });
  }

  getZones() {
    this.commonServices.getZoneList().subscribe((res) => (this.zones = res));
  }

  getRegions() {
    this.commonServices.getRegionList().subscribe((res) => {
      this.regions = res;
    });
  }

  getBranches() {
    this.commonServices.BranchList('maha', false).subscribe((res) => {
      this.branches = res;
    });
  }

  public getErrorMessage(controlName: string): string {
    return this.envFn.getFormError(this.formOverrideDetails, controlName);
  }

  setValue(obj: any, event: any) {
    console.log(this.checkBoxVal,"uuuuuuuuuuuuuuuuuVal");

    const found = this.checkBoxVal.find((element: any) => {
      return element.name === obj.name;
    });
    if (event.target.checked == true && !found) {
      {
        this.checkBoxVal.push({
          name: obj.name,
          val: event.target.checked,
        });
      }
    } else {
      if (event.target.checked == false && found) {
        for (let item of this.checkBoxVal) {
          if (obj.name === item.name) {
            this.checkBoxVal.splice(this.checkBoxVal.indexOf(item), 1);
            break;
          }
        }
      }
    }
    console.log(this.checkBoxVal,"this.checkBoxValthis.checkBoxVal");
    
    this.parentFun.emit(this.checkBoxVal);
  }

  saveValue(){
    if (
      this.formOverrideDetails.value.interestOverride == true ||
      this.formOverrideDetails.value.chargeOverride == true ||
      this.formOverrideDetails.value.limitOverride == true
    ) {
      this.overrideFlag = 0;
      this.formOverrideDetails.get('hideCheckbox')?.clearValidators();
      this.formOverrideDetails.get('hideCheckbox')?.updateValueAndValidity();
    } else {
      this.overrideFlag = 1;
      this.formOverrideDetails
        .get('hideCheckbox')
        ?.setValidators([Validators.required]);
      this.formOverrideDetails.get('hideCheckbox')?.updateValueAndValidity();
    }

    if (!this.formOverrideDetails.valid) {
      return;
    } else {
      this.commonServices.override.schemeId=this.formOverrideDetails.value.schemeName
      this.commonServices.override.groupTypeId=this.formOverrideDetails.value.schemeOverrideApplicable
      this.valueList.forEach((element:any) => this.commonServices.override.branchDetails.push( {"branchGroupId": element.id}));
     
    }
    console.log(   this.commonServices.override,"opoop")
   

  }

}
